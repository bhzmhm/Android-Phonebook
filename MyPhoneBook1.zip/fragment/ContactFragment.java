package com.isun.contactlist.fragment;


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.isun.contactlist.AddPersonActivity;
import com.isun.contactlist.MainActivity;
import com.isun.contactlist.R;
import com.isun.contactlist.adapter.PersonAdapter;
import com.isun.contactlist.database.AppDatabase;
import com.isun.contactlist.database.ContactDao;
import com.isun.contactlist.database.Person;

import java.util.ArrayList;
import java.util.List;

public class ContactFragment extends Fragment {


    public ContactFragment() {
        // Required empty public constructor
    }

    private FloatingActionButton add;
    private RecyclerView list;
    private TextView noContact,count;
    private EditText search;
    private PersonAdapter adapter;
    private List<Person> personList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_contact, container, false);

        list = v.findViewById(R.id.rec_contact);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        noContact = v.findViewById(R.id.txt_empty);
        count = v.findViewById(R.id.txt_count);

        personList = new ArrayList<>();
        adapter = new PersonAdapter(personList,getContext());
        list.setAdapter(adapter);

        add = v.findViewById(R.id.floatingActionButton);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), AddPersonActivity.class));
            }
        });

        search = v.findViewById(R.id.edt_search);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });

        getListFromDataBase();

        return v;
    }

    private void filter(String s) {

        List<Person> list = new ArrayList<>();

        if(!s.equals("")){
            for (Person person : personList)
                if(person.getFullName().contains(s) || person.getMobile().contains(s)|| person.getHomePhone().contains(s))
                    list.add(person);

            personList.clear();
            personList.addAll(list);
            adapter.notifyDataSetChanged();
        }
        else {
            personList.clear();
            getListFromDataBase();
        }
    }

    private void getListFromDataBase(){

        final ContactDao dao = AppDatabase.getDatabase(getContext()).contactDao();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                personList.addAll(dao.getAllPersons());

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        if(personList.size()>0){
                            noContact.setVisibility(View.GONE);
                            adapter.notifyDataSetChanged();
                        }
                        else {
                            noContact.setVisibility(View.VISIBLE);
                        }
                        count.setText("number of contacts : "+personList.size());
                    }
                });
            }
        });
    }

}
