package com.isun.contactlist.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.isun.contactlist.R;
import com.isun.contactlist.adapter.PersonAdapter;
import com.isun.contactlist.database.AppDatabase;
import com.isun.contactlist.database.ContactDao;
import com.isun.contactlist.database.Person;

import java.util.List;

public class FavoriteFragment extends Fragment {


    public FavoriteFragment() {
        // Required empty public constructor
    }

    private RecyclerView list;
    private TextView noContact;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_favorite, container, false);

        list = v.findViewById(R.id.rec_favorite);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        noContact = v.findViewById(R.id.txt_empty_favorite);

        getFavoriteListFromDataBase();

        return v;
    }

    private void getFavoriteListFromDataBase(){

        final ContactDao dao = AppDatabase.getDatabase(getContext()).contactDao();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                final List<Person> personList = dao.getFavoritePersons();

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(personList.size()>0){
                            noContact.setVisibility(View.GONE);
                            PersonAdapter adapter = new PersonAdapter(personList,getContext());
                            list.setAdapter(adapter);
                        }
                        else
                            noContact.setVisibility(View.VISIBLE);
                    }
                });
            }
        });
    }

}
