package com.isun.contactlist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.isun.contactlist.adapter.PersonAdapter;
import com.isun.contactlist.database.AppDatabase;
import com.isun.contactlist.database.ContactDao;
import com.isun.contactlist.database.Person;

import java.util.List;

public class PersonActivity extends AppCompatActivity {

    private TextView fullName, nickName, mobile, workPhone, homePhone, personalEmail, workEmail, birthDay, workAddress, homeAddress, websiteAddress, additionalNote;
    private Person person;
    private Button call,message,block,share,favorite,delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person);

        int id = getIntent().getExtras().getInt("ID");

        fullName = findViewById(R.id.txt_full_name);
        nickName = findViewById(R.id.txt_nick_name);
        mobile = findViewById(R.id.txt_mobile);
        workPhone = findViewById(R.id.txt_work_phone);
        homePhone = findViewById(R.id.txt_home_phone);
        personalEmail = findViewById(R.id.txt_personal_email);
        workEmail = findViewById(R.id.txt_work_email);
        birthDay = findViewById(R.id.txt_birthday);
        workAddress = findViewById(R.id.txt_work_address);
        homeAddress = findViewById(R.id.txt_home_address);
        websiteAddress = findViewById(R.id.txt_website);
        additionalNote = findViewById(R.id.txt_note);

        call = findViewById(R.id.btn_call);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_DIAL);
                i.setData(Uri.parse("tel:"+person.getMobile()));
                startActivity(i);
            }
        });

        message = findViewById(R.id.btn_message);
        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri sms_uri = Uri.parse("smsto:"+person.getMobile());
                Intent sms_intent = new Intent(Intent.ACTION_SENDTO, sms_uri);
                startActivity(sms_intent);
            }
        });

        block = findViewById(R.id.btn_block);
        block.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                blockPerson();
            }
        });

        share = findViewById(R.id.btn_share);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String shareBody = person.getFullName()+"\n"+person.getMobile();
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share..."));
            }
        });

        favorite = findViewById(R.id.btn_favorite);
        favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                favoritePerson();
            }
        });

        delete = findViewById(R.id.btn_delete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deletePerson();
            }
        });

        getPerson(id);
    }

    private void deletePerson() {
        final ContactDao dao = AppDatabase.getDatabase(this).contactDao();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                dao.deletePerson(person.getId());

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(PersonActivity.this,"Contact deleted.",Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
            }
        });
    }

    private void favoritePerson() {

        final ContactDao dao = AppDatabase.getDatabase(this).contactDao();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                dao.favoritePerson(person.getId(),!person.isFavorite());

                person = dao.getPerson(person.getId());

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(PersonActivity.this,person.isFavorite()?"Contact now is favorite!": "Contact now is not favorite!",Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void blockPerson() {

        final ContactDao dao = AppDatabase.getDatabase(this).contactDao();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                dao.blockPerson(person.getId(),!person.isBlocked());

                person = dao.getPerson(person.getId());

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(PersonActivity.this,person.isBlocked()?"Contact blocked!": "Contact unblocked!",Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void getPerson(final int id) {

        final ContactDao dao = AppDatabase.getDatabase(this).contactDao();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                person = dao.getPerson(id);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        fullName.setText(person.getFullName());
                        nickName.setText(person.getNickName());
                        mobile.setText(person.getMobile());
                        workPhone.setText(person.getWorkPhone());
                        homePhone.setText(person.getHomePhone());
                        personalEmail.setText(person.getPersonalEmail());
                        workEmail.setText(person.getWorkEmail());
                        birthDay.setText(person.getBirthDay());
                        workAddress.setText(person.getWorkAddress());
                        homeAddress.setText(person.getHomeAddress());
                        websiteAddress.setText(person.getWebsite());
                        additionalNote.setText(person.getNote());
                    }
                });
            }
        });
    }
}
