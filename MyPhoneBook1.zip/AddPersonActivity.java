package com.isun.contactlist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.isun.contactlist.adapter.PersonAdapter;
import com.isun.contactlist.database.AppDatabase;
import com.isun.contactlist.database.ContactDao;
import com.isun.contactlist.database.Person;

import java.util.List;

public class AddPersonActivity extends AppCompatActivity {

    private EditText fullName,nickName,mobile,workPhone,homePhone,personalEmail,workEmail,birthDay,workAddress,homeAddress,websiteAddress,additionalNote;
    private Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_person);

        fullName = findViewById(R.id.edt_full_name);
        nickName = findViewById(R.id.edt_nick_name);
        mobile = findViewById(R.id.edt_mobile);
        workPhone = findViewById(R.id.edt_work_phone);
        homePhone = findViewById(R.id.edt_home_phone);
        personalEmail = findViewById(R.id.edt_personal_email);
        workEmail = findViewById(R.id.edt_work_email);
        birthDay = findViewById(R.id.edt_birthday);
        workAddress = findViewById(R.id.edt_work_address);
        homeAddress = findViewById(R.id.edt_home_address);
        websiteAddress = findViewById(R.id.edt_website);
        additionalNote = findViewById(R.id.edt_note);

        save = findViewById(R.id.btn_save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!TextUtils.isEmpty(fullName.getText().toString())){
                    if(!TextUtils.isEmpty(mobile.getText().toString())){
                        Person person = new Person(fullName.getText().toString(),nickName.getText().toString(),null,mobile.getText().toString(),workPhone.getText().toString(),homePhone.getText().toString(),personalEmail.getText().toString(),workEmail.getText().toString(),birthDay.getText().toString(),workAddress.getText().toString(),homeAddress.getText().toString(),websiteAddress.getText().toString(),additionalNote.getText().toString(),false,false);
                        addPersonToDataBase(person);
                    }
                    else
                        Toast.makeText(AddPersonActivity.this,"Please enter mobile number!",Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(AddPersonActivity.this,"Please enter full name!",Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void addPersonToDataBase(final Person person) {

        final ContactDao dao = AppDatabase.getDatabase(AddPersonActivity.this).contactDao();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
               dao.insert(person);
            }
        });

        Toast.makeText(AddPersonActivity.this,"Contact Added.",Toast.LENGTH_SHORT).show();
        finish();

    }
}
