package com.isun.contactlist.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.isun.contactlist.PersonActivity;
import com.isun.contactlist.R;
import com.isun.contactlist.database.Person;

import java.util.List;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.MyViewHolder> {

    private List<Person> lst;
    private Context context;

    public PersonAdapter(List<Person> lst, Context context){
        this.lst= lst;
        this.context = context;
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name,mobile;
        LinearLayout lnr;
        MyViewHolder(@NonNull View v) {
            super(v);
            name = v.findViewById(R.id.txt_name);
            mobile = v.findViewById(R.id.txt_mobile);
            lnr = v.findViewById(R.id.lnr_person);

        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.person_item,viewGroup,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, int i) {
        final Person person  = lst.get(i);
        myViewHolder.name.setText(person.getFullName());
        myViewHolder.mobile.setText(person.getMobile());
        myViewHolder.lnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, PersonActivity.class);
                i.putExtra("ID",person.getId());
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return lst.size();
    }
}
