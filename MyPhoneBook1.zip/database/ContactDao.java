package com.isun.contactlist.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface ContactDao {

    @Insert
    void insert(Person person);

    @Query("select * from Person order by fullName")
    List<Person> getAllPersons();

    @Query("select * from Person where isFavorite = 1 order by fullName")
    List<Person> getFavoritePersons();

    @Query("select * from Person where id = :id")
    Person getPerson(int id);

    @Query("UPDATE Person SET isBlocked = :isBlocked WHERE id = :id")
    int blockPerson(int id, boolean isBlocked);

    @Query("UPDATE Person SET isFavorite = :isFavorite WHERE id = :id")
    int favoritePerson(int id, boolean isFavorite);

    @Query("DELETE FROM person WHERE id = :id")
    void deletePerson(int id);
}
