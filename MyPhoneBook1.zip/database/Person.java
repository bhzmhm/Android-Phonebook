package com.isun.contactlist.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "Person")
public class Person {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "fullName")
    private String fullName;

    @ColumnInfo(name = "nickName")
    private String nickName;

    @ColumnInfo(name = "image")
    private String image;

    @ColumnInfo(name = "mobile")
    private String mobile;

    @ColumnInfo(name = "workPhone")
    private String workPhone;

    @ColumnInfo(name = "homePhone")
    private String homePhone;

    @ColumnInfo(name = "personalEmail")
    private String personalEmail;

    @ColumnInfo(name = "workEmail")
    private String workEmail;

    @ColumnInfo(name = "birthDay")
    private String birthDay;

    @ColumnInfo(name = "workAddress")
    private String workAddress;

    @ColumnInfo(name = "homeAddress")
    private String homeAddress;

    @ColumnInfo(name = "website")
    private String website;

    @ColumnInfo(name = "note")
    private String note;

    @ColumnInfo(name = "isBlocked")
    private boolean isBlocked;

    @ColumnInfo(name = "isFavorite")
    private boolean isFavorite;

    public Person(int id, String fullName, String nickName, String image, String mobile, String workPhone, String homePhone, String personalEmail, String workEmail, String birthDay, String workAddress, String homeAddress, String website, String note, boolean isBlocked, boolean isFavorite) {
        this.id = id;
        this.fullName = fullName;
        this.nickName = nickName;
        this.image = image;
        this.mobile = mobile;
        this.workPhone = workPhone;
        this.homePhone = homePhone;
        this.personalEmail = personalEmail;
        this.workEmail = workEmail;
        this.birthDay = birthDay;
        this.workAddress = workAddress;
        this.homeAddress = homeAddress;
        this.website = website;
        this.note = note;
        this.isBlocked = isBlocked;
        this.isFavorite = isFavorite;
    }

    @Ignore
    public Person(String fullName, String nickName, String image, String mobile, String workPhone, String homePhone, String personalEmail, String workEmail, String birthDay, String workAddress, String homeAddress, String website, String note, boolean isBlocked, boolean isFavorite) {
        this.fullName = fullName;
        this.nickName = nickName;
        this.image = image;
        this.mobile = mobile;
        this.workPhone = workPhone;
        this.homePhone = homePhone;
        this.personalEmail = personalEmail;
        this.workEmail = workEmail;
        this.birthDay = birthDay;
        this.workAddress = workAddress;
        this.homeAddress = homeAddress;
        this.website = website;
        this.note = note;
        this.isBlocked = isBlocked;
        this.isFavorite = isFavorite;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getWorkPhone() {
        return workPhone;
    }

    public void setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
    }

    public String getHomePhone() {
        return homePhone;
    }

    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    public String getPersonalEmail() {
        return personalEmail;
    }

    public void setPersonalEmail(String personalEmail) {
        this.personalEmail = personalEmail;
    }

    public String getWorkEmail() {
        return workEmail;
    }

    public void setWorkEmail(String workEmail) {
        this.workEmail = workEmail;
    }

    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    public String getWorkAddress() {
        return workAddress;
    }

    public void setWorkAddress(String workAddress) {
        this.workAddress = workAddress;
    }

    public String getHomeAddress() {
        return homeAddress;
    }

    public void setHomeAddress(String homeAddress) {
        this.homeAddress = homeAddress;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public boolean isBlocked() {
        return isBlocked;
    }

    public void setBlocked(boolean blocked) {
        isBlocked = blocked;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }
}
